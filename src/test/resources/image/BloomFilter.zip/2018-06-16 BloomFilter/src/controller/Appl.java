package controller;

import model.FastBloomFilter;

public class Appl {

	public static void main(String[] args) {
		FastBloomFilter bf = new FastBloomFilter(1000, 10);
        System.out.println("Query for 2000: " + bf.mightContain(2000));
        System.out.println("Adding 2000");
        bf.add(2000);
        System.out.println("Query for 2000: " + bf.mightContain(2000));

	}

}
